This app explains, how SHA-256 works.

Music by Gena Sealov
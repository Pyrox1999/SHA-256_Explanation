import os
os.environ['SDL_VIDEO_WINDOW_POS'] = '100,100'
import random
import pgzrun
import pygame
import requests
import hashlib

random.seed()

pygame.mixer.music.load("song.mp3") #Gena Sealov
pygame.mixer.music.play(-1)

level=0

def draw():
    screen.clear()
    if level == 0:
        screen.blit("title", (0, 0))
    elif level == 1:
        screen.blit("page1", (0, 0))
    elif level == 2:
        screen.blit("page2", (0, 0))
    elif level == 3:
        screen.blit("page3", (0, 0))
    elif level == 4:
        screen.blit("page4", (0, 0))
    elif level == 5:
        screen.blit("page5", (0, 0))
    elif level == 6:
        screen.blit("page6", (0, 0))
    elif level == 7:
        screen.blit("page7", (0, 0))
    elif level == 8:
        screen.blit("page8", (0, 0))
    elif level == 9:
        screen.blit("page9", (0, 0))
    elif level == 10:
        screen.blit("page10", (0, 0))
    elif level == 11:
        screen.blit("page11", (0, 0))
    elif level == 12:
        screen.blit("page12", (0, 0))
    elif level == 13:
        screen.blit("page13", (0, 0))
    elif level == 14:
        screen.blit("page14", (0, 0))
    elif level == 15:
        screen.blit("page15", (0, 0))
    elif level == 16:
        screen.blit("page16", (0, 0))
    elif level == 17:
        screen.blit("page17", (0, 0))
    elif level == 18:
        screen.blit("page18", (0, 0))
    elif level == 19:
        screen.blit("page19", (0, 0))
    elif level == 20:
        screen.blit("page20", (0, 0))
    elif level == 21:
        screen.blit("page21", (0, 0))
    elif level == 22:
        screen.blit("page22", (0, 0))
    elif level == 23:
        screen.blit("page23", (0, 0))

def on_key_down(key, unicode=None):
    global level, url
    if key==keys.ESCAPE:
        pygame.quit()
    if key==keys.SPACE:
        level+=1

def update():
    global level,password,url,message,gemacht
   
    
pgzrun.go()
